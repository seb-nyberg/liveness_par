#ifndef error_h
#define error_h

void error(char* fmt, ...);
void syserror(int errnum, char* fmt, ...);

#endif

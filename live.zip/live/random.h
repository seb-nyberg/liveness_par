void init_random(int seed);
int next(void);
